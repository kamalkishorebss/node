var app=angular.module("myApp",['ngRoute','ngStorage']);
app.config(["$routeProvider","$locationProvider",function($routeProvider,$locationProvider){
	$routeProvider.
	when("/signup",{
	controller:"main",
	templateUrl:"/javascripts/view/signup.html"
	}).
	when("/login",{
	controller:"main",
	templateUrl:"/javascripts/view/login.html"
   }).
  when("/varifiEmail",{
  controller:"main",
  templateUrl:"/javascripts/view/varifyEmail.html"
   }).
  when("/profile",{
	controller:"profileController",
	templateUrl:"/javascripts/view/profile.html",
	resolve: {
		    logedin:checkLoggedin
	}
  }).
    otherwise({
	redirectTo:'/'
	});
 $locationProvider.html5Mode({
                 enabled: true,
                requireBase: false
              });
}])

app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                 modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);

app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]);
var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/users/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };
app.controller("profileController",function($scope,$http,$location,$localStorage){
$scope.message="you profile page";
 $http({
		method:"get",
		url:'/users/profile',
}).then(function successCallback(response){
   //alert("okk");
$scope.profieUser=response.data;
  console.log($scope.profieUser);
}, function errorCallback(res){
	console.log("error");
});
$scope.logout=function(){

$http({
		method:"get",
		url:'/users/logout',
}).then(function successCallback(response){
	$location.path('/login');
}, function errorCallback(res){
	console.log("error");
});

}
});

app.controller("main",function($scope,$http,$location,$localStorage,$routeParams,$q,$rootScope){
		

	$scope.signup = function(){
 var uploadUrl = "/users/signup";
        var fd = new FormData();
        console.log(fd);
         var file = $scope.registration.user.myFile;
        fd.append('name',$scope.registration.user.name);
        fd.append('username',$scope.registration.user.username);
        fd.append('email',$scope.registration.user.email);
        fd.append('password',$scope.registration.user.password);
        fd.append('gender',$scope.registration.user.gender);
        fd.append('file', file);
        
        console.log(' $scope.gender ',$scope.gender);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
           console.log("success!!");
          $location.path("/varifiEmail")
        })
        .error(function(){
          console.log("error!!");
        });
    };



$scope.mylogin=function(){
  console.log($scope.username,$scope.password);
		$http({
		method:"post",
		url:'/users/login',
		data:{username:$scope.username,password:$scope.password},
}).success(function(response){
           console.log("success!!");
          $location.path("/profile")
        }).error(function(response){
           console.log("error!!" ,response);
            $location.path("/login")
        });

}


$scope.userverification = function()
{
  http({
    method:"get",
    url:'/users/verify_email',
    data:{email:$scope.email,password:$scope.password},
}).success(function(response){
           console.log("success!!");
          $location.path("/login")
        }).error(function(response){
           console.log("error!!" ,response);
            
        });

}
  });
