var express = require('express');
var router = express.Router();
var paypal = require('paypal-rest-sdk');
var multer = require('multer');
var mime = require('mime-types');
var favicon = require('serve-favicon');
var nodemailer = require('nodemailer');
//****************** controllers************************//
var userController = require('../controller/usercontroller');
var usercontact = require('../controller/contactcontroller');
var userblog = require('../controller/addblogcontroller');


//***************uploadsimage in signup****************//
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });


//************************add image in addedblog ******************************************//
var blogupload = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploadsblog/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var uploadblog = multer({ storage: blogupload });


// paypal auth configuration
var config = {
  "port" : 3002,
  "api" : {
    "host" : "api.sandbox.paypal.com",
    "port" : "3002",            
    "client_id" : "AbS1MOelyJkxFNwWldrXeOMTCr1ilGnr0yKBpRXRcDTNC0yjpkMTY98Ev-3ZjdF0AWWaWonb8wgKhT60",  // your paypal application client id
    "client_secret" : "ECGuranG2tCs2d1YCmTAnx5H7Ks0AmsJ1BAZeZMLXC9T30p3a_x0ZapES45eG9frCm3VqVZK6GBk4wDx" // your paypal application secret id
  }
}
 paypal.configure(config.api);
 
// Page will display after payment has beed transfered successfully
router.get('/success', function(req, res) {
  res.send("Payment transfered successfully.");
});
 
// Page will display when you canceled the transaction 
router.get('/cancel', function(req, res) {
  res.send("Payment canceled successfully.");
});

router.post('/paynow', function(req, res) {
   // paypal payment configuration.
  var payment = {
  "intent": "sale",
  "payer": {
    "payment_method": "paypal"
  },
  "redirect_urls": {
    "return_url":"/success",
    "cancel_url":"/cancel"
  },
  "transactions": [{
    "amount": {
      "total":parseInt(req.body.amount),
      "currency":  req.body.currency
    },
    "description": req.body.description
  }]
};
 paypal.payment.create(payment, function (error, payment) {
  if (error) {
    console.log(error);
  } else {
    if(payment.payer.payment_method === 'paypal') {
      req.paymentId = payment.id;
      var redirectUrl;
      console.log(payment);
      for(var i=0; i < payment.links.length; i++) {
        var link = payment.links[i];
        if (link.method === 'REDIRECT') {
          redirectUrl = link.href;
        }
      }
      res.redirect(redirectUrl);
    }
  }
});
});


// routes 
router.post('/login',userController.login);


router.post('/signup', upload.single('file'), userController.signup);


router.post('/addblog', uploadblog.single('file'), userblog.addblog);


router.get('/home', userblog.home);


router.get('/listblog', userblog.listblog);
router.delete('/delete/:id', userblog.delete);
router.get('/blogview/:id', userblog.viewblog);
router.get('/editblog/:id',userblog.editblog);
router.post('/editblog/:id',userblog.saveEditblog);
router.get('/addcart/:id',userblog.addcart);


router.get('/profile', userController.profile);


router.post('/contact',usercontact.contact);


router.post('/costumer',userController.register);










module.exports = router;