var mongoose=require("mongoose");
var Schema=mongoose.Schema;

var userSchema=new Schema({
	local      : {
	name       :    String,
	username   :{ 
	             type: String, unique:true ,
	           },
	email      :{ 
	                type:String,unique:true
	            },
	password   : String,
	
	file:String,
	
	gender:String,
	
	authToken: {type: String, unique:true},
	isAuthenticated: Boolean,
	
    createdAt: {type: Date, required: true, default: Date.now, expires: '4h'}
}
});
var user=mongoose.model('user',userSchema);
module.exports=user;
