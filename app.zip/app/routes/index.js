var express = require('express');
var router = express.Router();
var users = require('../model/usermodel');
var auth = require('./auth');
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'login' });
});

router.get('/home',auth.authn, function(req, res, next) {
  res.render('home', {user : req.session.username});
});

router.get('/logout', function(req, res, next) {
  req.session.destroy(function(err){
	  if(err){
		  console.log("err", err);
	  }
	  else {
		  res.redirect('login');
	  }
  });
});


router.get('/signup', function(req, res, next) {
  res.render('signup', { title: 'signup' });
});

/*router.post('/login', function(req, res, next) {
  res.render('login', { title: 'login' });
});*/


router.post('/signup',function(req, res){
	var user = new users();
	user.firstname = req.body.firstname;
	user.lastname = req.body.lastname;
	user.email = req.body.email;
	user.password = req.body.password;
	user.DOB = req.body.DOB;
	user.Gender=req.body.Gender;
	
   user.save({},function(err, data){
	   if(err)
	   {
		   res.send(err);
	   }
	   else {
		   res.redirect('/login');
	   }
   });	
	});


//****************loginmatch***************//
router.post('/login', function(req, res, next) {
var email = req.body.email;
var password = req.body.password;
//console.log(email);
//console.log(password);
users.findOne({ email : email,password: password},function(err,person){
	if(err)
	{
		console.log("err", err);
    }
    else
    {
	    if(person)
	    {
		    if(person.password == password)
			{
				
				req.session.username = person;
				//console.log('222222222222222222');
				res.redirect('/viewUsers');
			}
			else
			{
				//console.log('1111111111111');
				res.send(err);
			}
		}
		else
		{
			//console.log('3333333333333');
			res.send({error:"email/password not valid"});
		}
    }
  });
});






//****************viewAllusers***********//
router.get('/viewUsers', function(req, res, next) {
	users.find({},function(err, data)
	{
		if(err)
		{
			res.send(err);
		}
		else
		{
			res.render("viewUsers", {user : data, logged:req.session.username});
		}
	});
  
});


//***********************delete*******************//
router.get('/delete/:id',function(req,res,next){
	var uid = req.params.id;
	users.findByIdAndRemove(uid,function(err)
{
	    if(err)
	{
		console.log(err);
	}	
	else
	{
		console.log("userDeleted");
		res.redirect('/viewUsers');
	}
});
	});
	
//**************************edit database row****************//	
	router.get('/edit/:id',function(req, res,next){
		var uid=req.params.id;
		users.findById(uid,function(err, person){
		
				res.render('edit',{data:person});
				//res.redirect('/login')
			
		});
	});

	
	router.post('/edit/:id',function(req,res,next){
		//var uid = req.parmas.id;
		//console.log(uid);
			console.log(req.body);
		users.findById(req.params.id, function(err, person)
		{
			person.firstname = req.body.firstname;
			person.lastname = req.body.lastname;
			person.email = req.body.email;
			person.DOB = req.body.DOB;
		person.save(function(err, data)
			{
			
			
				console.log("user edited");
				res.redirect('/home');
			
		})
	});
	});
module.exports = router;
