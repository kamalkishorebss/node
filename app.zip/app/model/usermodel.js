var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
firstname : String,
lastname : String,
email : { type:String , required:true ,unquie:true },
password : { type:Number, required:true },
DOB : String,
Gender : String
});

var User =mongoose.model('user',userSchema);

module.exports =User;




