var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var customerSchema = new Schema({
 name: {type:String},
 email: { type: String, required: true, unique: true },
 Phone: Number,
 address: String,
 pincode: Number
 
});



var User = mongoose.model('customer', customerSchema);

module.exports = User;
