var Usermodel = require('../model/contactmodel');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://kamalkishore273@gmail.com:98167kishore@smtp.gmail.com');

//****************************************contactus************************************//
module.exports.contact = function(req, res) {
// var contact = new Usermodel();
	var data = req.body;
	console.log(data);
 //contact.name = req.body.name;
 //contact.email = req.body.email;

    transporter.sendMail({
        from: data.email,
        to: 'kamalkishore273@gmail.com',
        subject: 'Message from ' + data.subject,
		name:data.name,
		address:data.address,
        text: data.message
    });
 
    res.json(data);

};