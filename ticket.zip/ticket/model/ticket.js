var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userticketSchema = new Schema({
 name: {type:String},
 email: { type: String, required: true},
 ticket: { type: Number, required: true}
});



var User = mongoose.model('ticket', userticketSchema);

module.exports = User;