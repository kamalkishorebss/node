var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 name: {type:String},
 email: { type: String, required: true }
 //ticket: { type: Number, required: true}
});



var ticket = mongoose.model('ticket', userSchema);

module.exports = ticket;
