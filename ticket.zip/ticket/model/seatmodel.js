var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var seatSchema = new Schema({
 row: {type:String},
 seat: Number
 });



var User = mongoose.model('seat', seatSchema);

module.exports = User;
