
var seatmodel = require('../model/seatmodel');

module.exports.seat =  function(req, res) 
{
    var user = new seatmodel();
    user.row = req.body.row;
    user.seat = req.body.seat;
   

	
    console.log(req.body);
    user.save(function (err, data) {
					if (err) 
					{
						//console.log(err);
						res.send(err);
						
					}
					else
						{
						//console.log("valueEnterd");
						res.send(data);
					    }
			
		});
}

//find viewseat list


module.exports.listseat=function(req, res)
	{
	
	 seatmodel.find({},function(err,data){
				if(err){
					console.log('err',err)
				}
				else
				{
					res.send(data);
					//console.log(data);
				}
								
			  
					
		});


	};
	
