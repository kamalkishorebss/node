var ticketmodel = require('../model/ticket');

module.exports.ticket =  function(req, res) 
{
    var user = new ticketmodel();
    user.name = req.body.name;
	user.email = req.body.email;
    user.ticket = req.body.ticket;
   

	
    console.log(req.body);
    user.save(function (err, data) {
					if (err) 
					{
						//console.log(err);
						res.send(err);
						
					}
					else
						{
						//console.log("valueEnterd");
						res.send(data);
					    }
			
		});
}
