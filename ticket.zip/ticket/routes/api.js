var express = require('express');
var router = express.Router();

var userController = require('../controller/usercontroller');
var seatController = require('../controller/seatcontroller');
var ticketController = require('../controller/ticketcontroller');


router.post('/login', userController.login);

router.post('/signup', userController.signup);
 
router.post('/addseat', seatController.seat);

router.post('/send', ticketController.ticket);

module.exports = router;