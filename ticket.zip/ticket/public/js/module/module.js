var app = angular.module("myApp",['ngRoute','ngStorage']);
app.config(function($routeProvider){
 $routeProvider.
 when('/login',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/login.html'
 }).
 when('/signup',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/signup.html'
 }).
 when('/addseat',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/addseat.html'
 }).
 when('/seatlist',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/seatlist.html'
 }).
 when('/Booknow',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/userdetail.html'
 }).
 when('/list',{
 controller: 'ticketcontroller',
 templateUrl: 'js/view/list.html'
 }).
 otherwise({
	 redirectTo:'/'
	 });
}); 

