app.controller("ticketcontroller",function($scope,$http, $localStorage,$location){
	
	$scope.signupPage = function()
	{
	$location.path('/signup');
	}
	
	
	$scope.signup = function() 
	{
    $http({
    method:"POST",
    url:'api/signup',
	data:{name:$scope.name, email:$scope.email,password:$scope.password}
     }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/login');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
	
	
	//login******************
	$scope.loginpage = function(){
		$http({
		  method: 'POST',
		  url: '/api/login',
		  data: {email:$scope.email, password:$scope.password}
		}).then(function successCallback(response) {
			if(response.data.error)
			{
				alert("Invalid email pasword");
			}
			else 
			{
		
				$scope.dp = response.data;
			    $localStorage.pp = $scope.dp;
				//console.log($localStorage.pp)
				$location.path('/addseat');
		    
			}
		}, function errorCallback(response) {
		  alert("Invalid email pasword");
		});
	}
	
	//***********addseat
	$scope.listdata =$localStorage.dd;

	$scope.addseat = function() 
	{
       $http({
              method:"POST",
              url:'api/addseat',
	    data:{row:$scope.row, seat:$scope.seat}
        }).then(function successCallback(response) {
           if(response.data.error){
              $scope.error = response.data.error;
             }else
			 {
               $scope.Blog=response.data;
               console.log($scope.Blog);
               $localStorage.dd=$scope.Blog;
               $location.path('/seatlist');
             }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	//****showing seat function********
	$scope.seats = function()
	{
		
     var s =   $localStorage.dd.seat;
     var a =parseInt(s);
     for(var i=0; i < s; i++)
        {
           document.getElementById("p1").innerHTML+= '<input type="checkbox">';
        }

	}
	
	//******book a seat**********
	
	$scope.detail=$localStorage.dp;
	$scope.Booknow = function()
	{
		$http({
               method:"POST",
               url:'api/addseat',
	    data:{name:$scope.name, email:$scope.email}
          }).
	      then(function successCallback(response) {
          if(response.data.error){
           $scope.error = response.data.error;
           }
		   else
		        {
                 $scope.Blog=response.data;
                 console.log($scope.Blog);
                 $localStorage.dp=$scope.Blog;
                 $location.path('/list');
                }
      
            }, function errorCallback(response) {
                 console.log('error',response);
            });
	}
	 
	$scope.bookdone = function()
	    {
	         alert("Booking success");	
	         $location.path('/login');
        }
		
		});
	
	
	
	